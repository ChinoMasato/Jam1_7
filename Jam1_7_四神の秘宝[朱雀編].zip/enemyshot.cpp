#include "en.h"
#include "DxLib.h"
#include "enemyshot.h"
#include "player.h"
#include "game.h"
#include "enemy.h"
#include "effect.h"
En enemyshot[EnemyShotNum];//�e
//�e�̏�����
void initEnemyShot()
{
	
	for (int i = 0; i < EnemyShotNum; i++) {
		enemyshot[i].r = 5;
		enemyshot[i].color = GetColor(255,0, 255);
		enemyshot[i].s= GetColor(0, 0, 255);
		enemyshot[i].fill = true;
		enemyshot[i].enable = false;
		enemyshot[i].img = LoadGraph("tamaa.png");
	}
}

//�e�̍X�V
void updateEnemyShot()
{
	//�e���L���ȂƂ��ɒe�𓮂���
	for (int i = 0; i < EnemyShotNum; i++)
	{
		if (enemyshot[i].enable == true) {
			enemyshot[i].x = enemyshot[i].x + enemyshot[i].vx;
			enemyshot[i].y = enemyshot[i].y + enemyshot[i].vy;
			if (enemyshot[i].x >= 800 ||
				enemyshot[i].x < 0 ||
				enemyshot[i].y >= 900 ||
				enemyshot[i].y < 100)
			{
				enemyshot[i].enable = false;
			}
		}
	}
	for (int j = 0; j < EnemyShotNum; j++) {
		if (enemyshot[j].enable) {
			if (isHit(player, enemyshot[j]))
			{
				player.s = player.s - 1;
				
				if (player.s <= 0)
				{
					explosion(player);//����
					player.color = enemyshot[j].color;
					gameOverFlag = true;//�Q�[���I�[�o�[�t���O�𗧂Ă�
				}
				enemyshot[j].enable = false;
			}
		}
	}
}
		

//�e�̕`��
void drawEnemyShot()
{
	for (int i = 0; i < EnemyShotNum; i++) {
		if (enemyshot[i].enable == true)
		{
		//	SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 15);
		//	DrawCircle(enemyshot[i].x, enemyshot[i].y, enemyshot[i].r, enemyshot[i].color, enemyshot[i].fill);
		//	SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
		//	DrawCircle(enemyshot[i].x, enemyshot[i].y, enemyshot[i].r * 0.5, enemyshot[i].s, enemyshot[i].fill);

			DrawGraph(enemyshot[i].x - 5, enemyshot[i].y - 5, enemyshot[i].img, true);
		}
	}
}