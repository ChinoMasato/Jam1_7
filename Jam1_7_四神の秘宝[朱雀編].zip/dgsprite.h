#pragma once
void initBg();
void updateBg();
void drawBg();