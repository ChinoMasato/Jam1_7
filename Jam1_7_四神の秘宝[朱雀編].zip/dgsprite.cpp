#include "DxLib.h"
#include "dgsprite.h"
int bgimg1;
int bgimg2;
double scrollX = 0;
double scrollX2 = -741;


void initBg()
{
	bgimg1 = LoadGraph("090.png");
	bgimg2 = LoadGraph("090.png");
}
void updateBg()
{
	scrollX = scrollX + 1.0;
	scrollX2 = scrollX2 + 1.0;
	
	if (scrollX >= 741.0)
	{
		scrollX = -741.0;
	}
	if (scrollX2 >= 741.0)
	{
		scrollX2 = -741.0;
	}

}
void drawBg()
{

	DrawGraph(0, scrollX, bgimg1, true);
	DrawGraph(0, scrollX2, bgimg2, true);

}