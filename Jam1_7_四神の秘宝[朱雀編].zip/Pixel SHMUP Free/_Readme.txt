	

	Pixel SHMUP Free

	Created by dylestorm (www.livingtheindie.com)

			------------------------------
			
	License and Usage
	
	You can edit, modify and use the assets in both commercial and non-commercial products.

	You cannot resell or distribute the assets (even if they are modified)		

	Follow me on Twitter for updates:
	https://twitter.com/livingtheindie