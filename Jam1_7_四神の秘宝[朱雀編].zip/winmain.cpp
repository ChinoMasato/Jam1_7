﻿#include "DxLib.h"
#include "player.h"
#include "shot.h"
#include "enemyshot.h"
#include "enemy.h"
#include "en.h"
#include "game.h"
#include"effect.h"
#include "dgsprite.h"

void init();//初期化関数のプロトタイプ宣言
void  titlelogoupdate();
void  logoupdate();
void  asdupdate();
void update();//更新関数のプロトタイプ宣言
void draw();//描画処理
int bgimg3;
int bgimg4;
double scrollX3 = 0;
double scrollX4 = -741;
enum GameSoene
{
	Title,
	Game,
	asd,
	pop
};
GameSoene scene = Title;
int TitleLogo;
int Logo;
int popLogo;
int se;
int sase;
int sas;
int popo;
int gag;
int aqaq;
// プログラムは WinMain から始まります
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	//DXライブラリの初期化処理 ここから
	ChangeWindowMode(TRUE);	//ウィンドウモードにする
	SetGraphMode(800, 740, 32);	//ウィンドウサイズを設定する
	if (DxLib_Init() == -1)		// ＤＸライブラリ初期化処理
	{
		return -1;			// エラーが起きたら直ちに終了
	}
	SetDrawScreen(DX_SCREEN_BACK);	//裏画面を描画対象へ
	//DXライブラリの初期化処理 ここまで

	init();//初期化処理の呼び出し　起動時一度だけ呼び出す

	//メインループ処理
	while (ProcessMessage() == 0 && CheckHitKey(KEY_INPUT_ESCAPE) == 0) {

		if (scene == Title)
		{
			titlelogoupdate();
		}
		else if (scene == Game)
		{
			update();//更新処理の呼び出し
		}
		else if (scene == asd)
		{
			asdupdate();
		}
		else if (scene == pop)
		{
			logoupdate();
		}
		ScreenFlip();		//裏画面と表画面の入替
		ClearDrawScreen();	//裏画面の描画を全て消去
	}
	//メインループ処理ここまで
	DeleteGraph(TitleLogo);
	DxLib_End();			// ＤＸライブラリ使用の終了処理

	return 0;				// ソフトの終了 
}
//初期化関数　引数、戻り値なし
void init()
{
	popo = LoadGraph("765.png");
	sas = LoadGraph("12345.png");
	sase = LoadSoundMem("4.mp3");
	TitleLogo = LoadGraph("0_72.png");
	Logo = LoadGraph("0111.png");
	popLogo = LoadGraph("0101.png");
	gag = LoadGraph("12122.png");
	se = LoadSoundMem("3.mp3");
	bgimg3 = LoadGraph("0099.png");
	bgimg4 = LoadGraph("0099.png");
	aqaq = LoadGraph("054.png");
	//プレイヤーの初期化
	initPlayer();
	initBg();
	//弾の初期化
	initShot();
	initEnemyShot();
	initEffect();
	//敵の初期化処理
	initEnemy();
	//タイトルBGMを再生
		PlayMusic("PerituneMaterial_Chinatown_Healing.mp3", DX_PLAYTYPE_LOOP);
}
void  titlelogoupdate()
{
	if (CheckHitKey(KEY_INPUT_RETURN) == 1)
{
		PlaySoundMem(se, DX_PLAYTYPE_BACK);
		scene = Game;
		PlayMusic("飛翔鉄塔.mp3", DX_PLAYTYPE_LOOP);
	}
	DrawGraph(-100, 0, sas, true);
	DrawGraph(720, 550, aqaq, true);
	DrawGraph(50, 50, TitleLogo, true);
	DrawFormatString(340, 600, GetColor(0, 0, 0), "エンターでスタート");
	DrawFormatString(0, 70, GetColor(0, 0, 0), "Zで大砲を発射");
	DrawFormatString(0, 90, GetColor(0, 0, 0), "方向キーで移動");
	
}
//更新関数
void update()
{

	//ゲーム(審判)の更新
	updateGame();
	//プレイヤーの更新
	updatePlayer();
	//弾の更新
	updateShot();
	updateEnemyShot();
	//敵の更新
	updateEnemy();
	updateEffect();
	//描画処理
	draw();
	updateBg();
	scrollX3 = scrollX3 + 1.5;
	scrollX4 = scrollX4 + 1.5;
	if (scrollX3 >= 741.0)
	{
		scrollX3 = -740.0;
	}
	if (scrollX4 >= 741.0)
	{
		scrollX4 = -741.0;
	}

	if (gameOverFlag == true) {
	scene = asd;
	PlaySoundMem(sase, DX_PLAYTYPE_BACK);
	PlayMusic("11.mp3", DX_PLAYTYPE_LOOP);
	}
	if (score == 10) {
	
				scene = pop;
				PlayMusic("12.mp3", DX_PLAYTYPE_LOOP);
			
	}
}
void asdupdate()
{
	DrawGraph(-140, 0, gag, true);
	DrawGraph(50, 0, Logo, true);
	DrawFormatString(360,550, GetColor(255, 255, 0), "撃破数 %d機", score);
	DrawFormatString(340, 580, GetColor(255, 0, 255), "スペースでリベンジ");
	if (CheckHitKey(KEY_INPUT_SPACE) == 1)
	{
		PlaySoundMem(se, DX_PLAYTYPE_BACK);
		scene = Title;
		init();
		gameOverFlag = false;
		score = 0;
	}
	
}
void  logoupdate()
{
	DrawGraph(-140, 0, popo, true);
	DrawGraph(70, 0, popLogo, true);
	DrawFormatString(360, 450, GetColor(255, 255, 255), "撃破数 %d機", score);
	DrawFormatString(310, 500, GetColor(255, 255, 255), "スペースでリスタート");
	if (CheckHitKey(KEY_INPUT_SPACE) == 1)
	{
		PlaySoundMem(se, DX_PLAYTYPE_BACK);
		scene = Title;
		init();
		gameOverFlag = false;
		score = 0;
	}
}
//描画処理
void draw()
{
	drawBg();
	
	//弾の描画
	drawShot();
	drawEnemyShot();
	//敵の描画
	drawEnemy();
	//プレイヤーの描画
	drawPlayer();
	drawEffect();
	SetDrawBlendMode(DX_BLENDMODE_ALPHA, 220);//半透明
	DrawGraph(0, scrollX3, bgimg3, true);
	DrawGraph(0, scrollX4, bgimg4, true);
	SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
	//ゲーム関連の描画
	drawGame();

}
