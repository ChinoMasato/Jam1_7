#include "en.h"
#include "DxLib.h"
#include "shot.h"


En shot[ShotNum];//�e
//�e�̏�����
void initShot()
{
	for (int i = 0; i < ShotNum; i++) {
		shot[i].r = 5;
		shot[i].color = GetColor(255, 255, 0);
		shot[i].fill = true;
		shot[i].vx =0.0;
		shot[i].vy = -5.0;
		shot[i].enable = false;
		shot[i].img = LoadGraph("tamaa.png");
	}
}
//�e�̍X�V
void updateShot()
{
	//�e���L���ȂƂ��ɒe�𓮂���
	for (int i = 0; i < ShotNum; i++)
	{
		if (shot[i].enable == true) {
			shot[i].x = shot[i].x + shot[i].vx;
			shot[i].y = shot[i].y + shot[i].vy;
			if (shot[i].y <= 0) {
				shot[i].enable = false;
			}
		}
	}
}
//�e�̕`��
void drawShot()
{
	for (int i = 0; i < ShotNum; i++) {
		if (shot[i].enable == true)
		{
			DrawGraph(shot[i].x - 5, shot[i].y - 5, shot[i].img, true);
			//SetDrawBlendMode(DX_BLENDMODE_ALPHA, 127);
			//DrawCircle(shot[i].x, shot[i].y, shot[i].r, shot[i].color, shot[i].fill);
			//SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
			//DrawCircle(shot[i].x, shot[i].y, shot[i].r  * 0.5, shot[i].color, shot[i].fill);
		}
	}
}