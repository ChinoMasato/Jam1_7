#include "en.h"
#include "DxLib.h"
#include <math.h>
#include "shot.h"
#include "enemyshot.h"
#include "enemy.h"
#include "player.h"
#include "game.h"
#include"effect.h"

int  color = GetColor(255, 255, 255);
int  colora = GetColor(255, 0, 0);
int pqw = 0;
int ense;
int  shedse;
int tori;
extern bool gameOverFlag;//�Q�[���I�[�o�[����
En enemy[EnemyNum];//�G
//�G�̏�����
void initEnemy()
{
	
	ense = LoadSoundMem("2.mp3");
	shedse = LoadSoundMem("5.mp3");
	tori = LoadSoundMem("yyy.mp3");
	//1�̖ڂ̓G
	enemy[0].x = 400;
	enemy[0].y = -100;
	enemy[0].r = 30;
	enemy[0].color = GetColor(255, 0, 0);
	enemy[0].fill = true;
	enemy[0].enable = true;
	enemy[0].vx =0.0;
	enemy[0].vy = 2.0;
	enemy[0].s = 100;
	enemy[0].img = LoadGraph("66.png");
	//2�̖ڂ̓G
	enemy[1].x = 600;
	enemy[1].y = -100;
	enemy[1].r = 30;
	enemy[1].color = GetColor(255, 0, 0);
	enemy[1].fill = true;
	enemy[1].enable = true;
	enemy[1].vx =0.0;
	enemy[1].vy = 2.0;
	enemy[1].s = 100;
	enemy[1].img = LoadGraph("66.png");

	//3�̖ڂ̓G
	enemy[2].x = 200;
	enemy[2].y = -100;
	enemy[2].r = 30;
	enemy[2].color = GetColor(255, 0, 0);
	enemy[2].fill = true;
	enemy[2].enable = true;
	enemy[2].vx = 0.0;
	enemy[2].vy = 2.0;
	enemy[2].s = 100;
	enemy[2].img = LoadGraph("66.png");

	//2�̖ڂ̓G
	enemy[3].x = 400;
	enemy[3].y = -100;
	enemy[3].r = 30;
	enemy[3].color = GetColor(255, 0, 0);
	enemy[3].fill = true;
	enemy[3].enable = false;
	enemy[3].vx = 0.0;
	enemy[3].vy = 2.0;
	enemy[3].s = 500;
	enemy[3].img = LoadGraph("662.png");
	//3�̖ڂ̓G
	enemy[4].x = 600;
	enemy[4].y = -100;
	enemy[4].r = 30;
	enemy[4].color = GetColor(255, 0, 0);
	enemy[4].fill = true;
	enemy[4].enable = false;
	enemy[4].vx = 0.0;
	enemy[4].vy = 2.0;
	enemy[4].s = 500;
	enemy[4].img = LoadGraph("664.png");
	//2�̖ڂ̓G
	enemy[5].x = 200;
	enemy[5].y = -100;
	enemy[5].r = 30;
	enemy[5].color = GetColor(255, 0, 0);
	enemy[5].fill = true;
	enemy[5].enable = false;
	enemy[5].vx = 0.0;
	enemy[5].vy = 2.0;
	enemy[5].s =500;
	enemy[5].img = LoadGraph("664.png");
	//3�̖ڂ̓G
	enemy[6].x = 500;
	enemy[6].y = -100;
	enemy[6].r = 30;
	enemy[6].color = GetColor(255, 0, 0);
	enemy[6].fill = true;
	enemy[6].enable = false;
	enemy[6].vx = 0.0;
	enemy[6].vy = 2.0;
	enemy[6].s = 300;
	enemy[6].img = LoadGraph("664.png");
	//2�̖ڂ̓G
	enemy[7].x = 300;
	enemy[7].y = -100;
	enemy[7].r = 30;
	enemy[7].color = GetColor(255, 0, 0);
	enemy[7].fill = true;
	enemy[7].enable = false;
	enemy[7].vx = 0.0;
	enemy[7].vy = 2.0;
	enemy[7].s = 300;
	enemy[7].img = LoadGraph("664.png");
	//3�̖ڂ̓G
	enemy[8].x = 400;
	enemy[8].y = -100;
	enemy[8].r = 130;
	enemy[8].color = GetColor(255, 0, 0);
	enemy[8].fill = true;
	enemy[8].enable = false;
	enemy[8].vx = 0.0;
	enemy[8].vy = 2.0;
	enemy[8].s = 1000;
	enemy[8].img = LoadGraph("2434.png");
	//2�̖ڂ̓G
	enemy[9].x = 400;
	enemy[9].y = -500;
	enemy[9].r = 30;
	enemy[9].color = GetColor(255, 0, 0);
	enemy[9].fill = true;
	enemy[9].enable = false;
	enemy[9].vx = 0.0;
	enemy[9].vy = 2.0;
	enemy[9].s = 500;
	enemy[9].img = LoadGraph("enemy_1_�S.png");

}
void straightShot(int rad, En ene)
{
	//�e�������ȂƂ��̂ݏ����l���Z�b�g���L���ɂ���
	for (int j = 0; j < EnemyShotNum; j++)
	{
		
		//���Ă�e���݂���
		if (enemyshot[j].enable == false) {
			//�e������
			enemyshot[j].x = ene.x;
			enemyshot[j].y = ene.y;
			double PI = 3.14159265358979323846264338;
			double minrad = PI / 180.0;//1�x�̃��W�A��
			double speed = 3.0;//���x
			enemyshot[j].vx = speed * sin(minrad * rad);
			enemyshot[j].vy = -speed * cos(minrad * rad);
			//PlaySoundMem(shedse, DX_PLAYTYPE_BACK);
			enemyshot[j].enable = true;
			break;
		}
	}
}

//�_���Č���
void aimShot(En ene)
{
	//�e�����Ă���
//�e�������ȂƂ��̂ݏ����l���Z�b�g���L���ɂ���
	for (int j = 0; j < EnemyShotNum; j++)
	{
		//���Ă�e���݂���
		if (enemyshot[j].enable == false) {
			//�e������
			enemyshot[j].x = ene.x;
			enemyshot[j].y = ene.y;

			double speed = 5.0;//���x
			double dx = player.x - ene.x;//�v���C���[�ƓG��x�����̋���
			double dy = player.y - ene.y;//�v���C���[�ƓG��y�����̋���
			double d = sqrt(dx * dx + dy * dy);//�G�ƃv���C���[�Ƃ̋���
			enemyshot[j].vx = speed * (dx / d);//x�̈ړ���
			enemyshot[j].vy = speed * (dy / d);//y�̈ړ���
			PlaySoundMem(shedse, DX_PLAYTYPE_BACK);
			enemyshot[j].enable = true;

			break;
		}
	}
}



//�G�̍X�V
void updateEnemy()
{
	if (enemy[8].s == 500) {
		PlaySoundMem(tori, DX_PLAYTYPE_BACK);
	}
	for (int i = 0; i < EnemyNum; i++) {

		if (enemy[i].enable == true) {
			//�G�������œ�����
			enemy[i].y = enemy[i].y + enemy[i].vy;
			enemy[i].x = enemy[i].x + enemy[i].vx;
			
			if(i == 3 || i == 5 || i == 4)
			{
				if (enemy[i].y >= 102) {
					//�������[�ɏo����
					enemy[i].vy = 0;
					enemy[i].y = 100;
					enemy[i].vx = 1;
				}
			}
			else if(i ==8)
			{ 
				if (enemy[i].y >= 152) {
					//�������[�ɏo����
					enemy[i].vy = 0;
					enemy[i].y = 150;

				}
			}
			else if (enemy[i].y >= 152)
			{
				//�������[�ɏo����
				enemy[i].vy = 0;
				enemy[i].y = 150;

				enemy[i].vx = 1;
			}
			if (enemy[9].y >= -100)
			{
				score++;
			}
			if(i == 0)
			{
				if (enemy[i].x > 450) {
					//�����E�[�ɏo����
					enemy[i].vx = -1;
				}
				if (enemy[i].x < 350 ) {
					//�������[�ɏo����
					enemy[i].vx = 1;
				}
			}
			if (i == 1)
			{
				if (enemy[i].x > 650) {
					//�����E�[�ɏo����
					enemy[i].vx = -1;
				}
				if (enemy[i].x < 550) {
					//�������[�ɏo����
					enemy[i].vx = 1;
				}
			}
			if (i == 2)
			{
				if (enemy[i].x > 250) {
					//�����E�[�ɏo����
					enemy[i].vx = -1;
				}
				if (enemy[i].x < 150) {
					//�������[�ɏo����
					enemy[i].vx = 1;
				}
			}
			if (i == 3)
			{
				if (enemy[i].x > 450) {
					//�����E�[�ɏo����
					enemy[i].vx = -1;
				}
				if (enemy[i].x < 350) {
					//�������[�ɏo����
					enemy[i].vx = 1;
				}
			}
			if (i == 4)
			{
				if (enemy[i].x > 650) {
					//�����E�[�ɏo����
					enemy[i].vx = -1;
				}
				if (enemy[i].x < 550) {
					//�������[�ɏo����
					enemy[i].vx = 1;
				}
			}
			if (i == 5)
			{
				if (enemy[i].x > 250) {
					//�����E�[�ɏo����
					enemy[i].vx = -1;
				}
				if (enemy[i].x < 150) {
					//�������[�ɏo����
					enemy[i].vx = 1;
				}
			}
			if (i == 6)
			{
				if (enemy[i].x > 550) {
					//�����E�[�ɏo����
					enemy[i].vx = -1;
				}
				if (enemy[i].x < 450) {
					//�������[�ɏo����
					enemy[i].vx = 1;
				}
			}
			if (i == 7)
			{
				if (enemy[i].x > 350) {
					//�����E�[�ɏo����
					enemy[i].vx = -1;
				}
				if (enemy[i].x < 250) {
					//�������[�ɏo����
					enemy[i].vx = 1;
				}
			}
		
			//�e�𔭎˂���
			if (canEnemyShot(enemy[i]))
			{
				if (enemy[0].enable == true) {
					straightShot(180, enemy[i]);
					
					enemy[i].cooltime = 50;//�A�ˑ��x�@�������قǘA�˂ł���
					break;
				}

			if (enemy[1].enable == true) {
					straightShot(180, enemy[i]);
					
					enemy[i].cooltime = 50;//�A�ˑ��x�@�������قǘA�˂ł���
					break;
				}
		
			if (enemy[2].enable == true) {
				straightShot(180, enemy[i]);

				enemy[i].cooltime = 50;//�A�ˑ��x�@�������قǘA�˂ł���
				break;
			}

			if (enemy[3].enable == true) {
				straightShot(180, enemy[i]);

				enemy[i].cooltime = 50;//�A�ˑ��x�@�������قǘA�˂ł���
				break;
			}
			if (enemy[4].enable == true) {
				straightShot(180, enemy[i]);
				
			enemy[i].cooltime = 50;//�A�ˑ��x�@�������قǘA�˂ł���
							break;
			}
				if (enemy[5].enable == true) {
					straightShot(180, enemy[i]);
					enemy[i].cooltime=50;//�A�ˑ��x�@�������قǘA�˂ł���
					break;
				}
				if (enemy[6].enable == true) {
					straightShot(180, enemy[i]);
					
					enemy[i].cooltime = 50;//�A�ˑ��x�@�������قǘA�˂ł���
					break;
				}
				if (enemy[7].enable == true) {
					straightShot(180, enemy[i]);
					
					
					enemy[i].cooltime = 50;//�A�ˑ��x�@�������قǘA�˂ł���
					break;
				}
				if (enemy[8].enable == true) {
					if (enemy[8].s <= 500) {
						straightShot(90, enemy[i]);
						straightShot(95, enemy[i]);
						straightShot(100, enemy[i]);
						straightShot(105, enemy[i]);
						straightShot(110, enemy[i]);
						straightShot(115, enemy[i]);
						straightShot(120, enemy[i]);
						straightShot(125, enemy[i]);
						straightShot(130, enemy[i]);
						straightShot(135, enemy[i]);
						straightShot(140, enemy[i]);
						straightShot(145, enemy[i]);
						straightShot(150, enemy[i]);
						straightShot(155, enemy[i]);
						straightShot(160, enemy[i]);
						straightShot(165, enemy[i]);
						straightShot(170, enemy[i]);
						straightShot(175, enemy[i]);
						straightShot(180, enemy[i]);
						straightShot(185, enemy[i]);
						straightShot(190, enemy[i]);
						straightShot(195, enemy[i]);
						straightShot(200, enemy[i]);
						straightShot(205, enemy[i]);
						straightShot(210, enemy[i]);
						straightShot(215, enemy[i]);
						straightShot(220, enemy[i]);
						straightShot(225, enemy[i]);
						straightShot(230, enemy[i]);
						straightShot(235, enemy[i]);
						straightShot(240, enemy[i]);
						straightShot(245, enemy[i]);
						straightShot(250, enemy[i]);
						straightShot(255, enemy[i]);
						straightShot(260, enemy[i]);
						straightShot(265, enemy[i]);
						straightShot(270, enemy[i]);
					}
					else {
						for (int j = 0; j < EnemyShotNum; j++)
						{
							//���Ă�e���݂���
							if (enemyshot[j].enable == false) {
								enemyshot[j].img = LoadGraph("hane.png");
							}
						}
						straightShot(90, enemy[i]);
						straightShot(100, enemy[i]);
						straightShot(110, enemy[i]);
						straightShot(120, enemy[i]);
						straightShot(130, enemy[i]);
						straightShot(140, enemy[i]);
						straightShot(150, enemy[i]);
						straightShot(160, enemy[i]);
						straightShot(170, enemy[i]);
						straightShot(180, enemy[i]);
						straightShot(190, enemy[i]);
						straightShot(200, enemy[i]);
						straightShot(210, enemy[i]);
						straightShot(220, enemy[i]);
						straightShot(230, enemy[i]);
						straightShot(240, enemy[i]);
						straightShot(250, enemy[i]);
						straightShot(260, enemy[i]);
						straightShot(270, enemy[i]);
					}
				

					enemy[i].cooltime = 50;//�A�ˑ��x�@�������قǘA�˂ł���
					break;
				}
				if (enemy[9].enable == true) {
					straightShot(90, enemy[i]);
					straightShot(100, enemy[i]);
					straightShot(110, enemy[i]);
					straightShot(120, enemy[i]);
					straightShot(130, enemy[i]);
					straightShot(140, enemy[i]);
					straightShot(150, enemy[i]);
					straightShot(160, enemy[i]);
					straightShot(170, enemy[i]);
					straightShot(180, enemy[i]);
					straightShot(190, enemy[i]);
					straightShot(200, enemy[i]);
					straightShot(210, enemy[i]);
					straightShot(220, enemy[i]);
					straightShot(230, enemy[i]);
					straightShot(240, enemy[i]);
					straightShot(250, enemy[i]);
					straightShot(260, enemy[i]);
					straightShot(270, enemy[i]);
					enemy[i].cooltime = 50;//�A�ˑ��x�@�������قǘA�˂ł���
					break;
				}

		}

	}
}
for (int i = 0; i < EnemyNum; i++) {
	if (enemy[i].enable)
	{
		if (isHit(player, enemy[i]))
		{
			//�������Ă���
			player.s = player.s - 1;
		
			if (player.s <= 0)
			{
				
				player.color = enemy[i].color;
				gameOverFlag = true;//�Q�[���I�[�o�[�t���O�𗧂Ă�
			}
		}
		
		if (enemy[i].y >= 99) {

			for (int j = 0; j < ShotNum; j++) {
				
				//�G�ƒe�Ƃ̓����蔻��
				if (shot[j].enable == true) {
					if (isHit(shot[j], enemy[i]))
					{
						enemy[i].s= enemy[i].s - 10;
					
						if (enemy[i].s <= 0) {
							//�������Ă���
							
							explosion(enemy[i]);//����
							enemy[i].enable = false;//�G�𖳌�
							PlaySoundMem(ense, DX_PLAYTYPE_BACK);
							if (enemy[0].enable == false &&
								enemy[1].enable == false &&
								enemy[2].enable == false)
							{
								if (enemy[0].s <= 0)
								{
									enemy[3].enable = true;//�G�𖳌�
									enemy[4].enable = true;//�G�𖳌�
									enemy[5].enable = true;//�G�𖳌�}
									enemy[6].enable = true;//�G�𖳌�
									enemy[7].enable = true;//�G�𖳌�
									for (int a = 0; a < ShotNum; a++) {
										shot[a].enable = false;//�e�𖳌�
									}
									enemy[0].s = 1;
								}
								
							}
								if (enemy[0].enable == false &&
									enemy[1].enable == false &&
									enemy[2].enable == false &&
									enemy[3].enable == false &&
									enemy[4].enable == false &&
									enemy[5].enable == false&&
									enemy[6].enable == false &&
									enemy[7].enable == false)
								{
									PlaySoundMem(tori, DX_PLAYTYPE_BACK);
										enemy[8].enable = true;//�G�𖳌�
										for (int a = 0; a < ShotNum; a++) {
											shot[a].enable = false;//�e�𖳌�
										}
										
								}
								if 
									(enemy[8].s == 0)
								{
									enemy[8].enable = false;//�G�𖳌�
									enemy[9].enable = true;//�G�𖳌�
									for (int a = 0; a < ShotNum; a++) {
										shot[a].enable = false;//�e�𖳌�
									}

								}
							
							score++;
							break;
						}
							
							shot[j].enable = false;
						
					}
				}
			}
		}
		//�e���₷����
		if (enemy[i].cooltime >= 1) {
			enemy[i].cooltime--;
		}
	}
}
}

//�G�̕`��
void drawEnemy()
{
	if (player.s <= 10)
	{
		DrawFormatString(player.x, player.y + 40, colora, "%dHP", player.s);
	}
	else{ DrawFormatString(player.x, player.y + 40, color, "%dHP", player.s); }

	for (int i = 0; i < EnemyNum; i++) {
		
		if (i == 0)
		{
			if (enemy[i].enable == true) {
				//DrawCircle(enemy[i].x, enemy[i].y, enemy[i].r, enemy[i].color, enemy[i].fill);
				DrawGraph(enemy[i].x - 25, enemy[i].y - 30, enemy[i].img, true);
				DrawFormatString(enemy[i].x - 20, enemy[i].y - 40, color, "%dHP", enemy[i].s);
			}
			if (enemy[i + 1].enable == true) {
				//DrawCircle(enemy[i].x, enemy[i].y, enemy[i].r, enemy[i].color, enemy[i].fill);
				DrawGraph(enemy[i + 1].x - 25, enemy[i + 1].y - 30, enemy[i + 1].img, true);
				DrawFormatString(enemy[i +1].x - 20, enemy[i +1].y - 40, color, "%dHP", enemy[i +1].s);
			}
			if (enemy[i + 2].enable == true) {
				//DrawCircle(enemy[i].x, enemy[i].y, enemy[i].r, enemy[i].color, enemy[i].fill);
				DrawGraph(enemy[i + 2].x - 25, enemy[i + 2].y - 30, enemy[i + 2].img, true);
				DrawFormatString(enemy[i +2].x - 20, enemy[+2].y - 40, color, "%dHP", enemy[i+2].s);
			}
		}
		if (i == 3)
		{
			if (enemy[i].enable == true) {
				//DrawCircle(enemy[i].x, enemy[i].y, enemy[i].r, enemy[i].color, enemy[i].fill);
				DrawGraph(enemy[i].x - 25, enemy[i].y - 30, enemy[i].img, true);
				DrawFormatString(enemy[i].x - 20, enemy[i].y - 40, color, "%dHP", enemy[i].s);
			}
			if (enemy[i + 1].enable == true) {
				//DrawCircle(enemy[i].x, enemy[i].y, enemy[i].r, enemy[i].color, enemy[i].fill);
				DrawGraph(enemy[i + 1].x - 25, enemy[i + 1].y - 30, enemy[i + 1].img, true);
				DrawFormatString(enemy[i+1].x - 20, enemy[i+1].y - 40, color, "%dHP", enemy[i+1].s);
			}
			if (enemy[i + 2].enable == true) {
				//DrawCircle(enemy[i].x, enemy[i].y, enemy[i].r, enemy[i].color, enemy[i].fill);
				DrawGraph(enemy[i + 2].x - 25, enemy[i + 2].y - 30, enemy[i + 2].img, true);
				DrawFormatString(enemy[i+2].x - 20, enemy[i+2].y - 40, color, "%dHP", enemy[i+2].s);
			}
			if (enemy[i + 3].enable == true) {
				//DrawCircle(enemy[i].x, enemy[i].y, enemy[i].r, enemy[i].color, enemy[i].fill);
				DrawGraph(enemy[i + 3].x - 25, enemy[i + 3].y - 30, enemy[i + 3].img, true);
				DrawFormatString(enemy[i+3].x - 20, enemy[i+3].y - 40, color, "%dHP", enemy[i+3].s);
			}
			if (enemy[i + 4].enable == true) {
				//DrawCircle(enemy[i].x, enemy[i].y, enemy[i].r, enemy[i].color, enemy[i].fill);
				DrawGraph(enemy[i + 4].x - 25, enemy[i + 4].y - 30, enemy[i + 4].img, true);
				DrawFormatString(enemy[i+4].x - 20, enemy[i+4].y - 40, color, "%dHP", enemy[i+4].s);
			}
		}
		if (i == 8)
		{
			if (enemy[i].enable == true) {
				//DrawCircle(enemy[i].x, enemy[i].y, enemy[i].r, enemy[i].color, enemy[i].fill);
				DrawGraph(enemy[i].x - 150, enemy[i].y - 150, enemy[i].img, true);
				DrawFormatString(enemy[i].x -50, enemy[i].y - 100, color, "%dHP", enemy[i].s);
			
			}
		}
	}
}
//�e�����Ă邩�m�F����֐�
bool canEnemyShot(En enemy)
{
	//�e���₦�Ă���
	if (enemy.cooltime <= 0) {
		if(enemy.x >=0 &&
			enemy.x < 800 &&
			enemy.y>0 &&
			enemy.y < 600)
		{
			//��ʂ̒��ɂ���
			return true;
		}
	}

	return false;
}